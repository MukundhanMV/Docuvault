import { relations } from "drizzle-orm";
import { users, documents, activities, verificationLogs } from "./schema";

// ───────────────────────────────────────────────────────────────
// Users can have many documents, activities, and verification logs
// ───────────────────────────────────────────────────────────────

export const usersRelations = relations(users, ({ many }) => ({
  documents: many(documents, { relationName: "userDocuments" }),
  activities: many(activities, { relationName: "userActivities" }),
  verifications: many(verificationLogs, { relationName: "userVerifications" }),
}));

// ───────────────────────────────────────────────────────────────
// Documents belong to a user (uploader) and optionally a verifier
// ───────────────────────────────────────────────────────────────

export const documentsRelations = relations(documents, ({ one, many }) => ({
  uploader: one(users, {
    fields: [documents.uploadedBy],
    references: [users.id],
    relationName: "userDocuments",
  }),
  verifier: one(users, {
    fields: [documents.verifiedBy],
    references: [users.id],
    relationName: "documentVerifier",
  }),
  verificationLogs: many(verificationLogs, { relationName: "documentVerificationLogs" }),
}));

// ───────────────────────────────────────────────────────────────
// Activities belong to a user
// ───────────────────────────────────────────────────────────────

export const activitiesRelations = relations(activities, ({ one }) => ({
  user: one(users, {
    fields: [activities.userId],
    references: [users.id],
    relationName: "userActivities",
  }),
}));

// ───────────────────────────────────────────────────────────────
// Verification logs belong to a document and a verifier user
// ───────────────────────────────────────────────────────────────

export const verificationLogsRelations = relations(verificationLogs, ({ one }) => ({
  document: one(documents, {
    fields: [verificationLogs.documentId],
    references: [documents.id],
    relationName: "documentVerificationLogs",
  }),
  verifier: one(users, {
    fields: [verificationLogs.verifiedBy],
    references: [users.id],
    relationName: "userVerifications",
  }),
}));
