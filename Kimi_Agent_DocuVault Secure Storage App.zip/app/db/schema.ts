import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  bigint,
} from "drizzle-orm/mysql-core";

// ───────────────────────────────────────────────────────────────
// Users table — stores accounts synced from Kimi OAuth
// ───────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("union_id", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("last_sign_in_at").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ───────────────────────────────────────────────────────────────
// Documents table — stores document metadata
// ───────────────────────────────────────────────────────────────
export const documents = mysqlTable("documents", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", ["legal", "finance", "identity", "medical", "education", "other"]).notNull(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  fileSize: int("file_size").notNull(),
  fileType: varchar("file_type", { length: 100 }).notNull(),
  blobUrl: varchar("blob_url", { length: 500 }).notNull(),
  status: mysqlEnum("status", ["pending", "verified", "rejected"]).default("pending").notNull(),
  rejectionReason: text("rejection_reason"),
  uploadedBy: bigint("uploaded_by", { mode: "number", unsigned: true }).notNull(),
  verifiedBy: bigint("verified_by", { mode: "number", unsigned: true }),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

// ───────────────────────────────────────────────────────────────
// Activities table — stores user activity log
// ───────────────────────────────────────────────────────────────
export const activities = mysqlTable("activities", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  targetId: bigint("target_id", { mode: "number", unsigned: true }),
  targetType: varchar("target_type", { length: 50 }),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;

// ───────────────────────────────────────────────────────────────
// Verification logs table — stores detailed verification history
// ───────────────────────────────────────────────────────────────
export const verificationLogs = mysqlTable("verification_logs", {
  id: serial("id").primaryKey(),
  documentId: bigint("document_id", { mode: "number", unsigned: true }).notNull(),
  verifiedBy: bigint("verified_by", { mode: "number", unsigned: true }).notNull(),
  previousStatus: mysqlEnum("previous_status", ["pending", "verified", "rejected"]).notNull(),
  newStatus: mysqlEnum("new_status", ["pending", "verified", "rejected"]).notNull(),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type VerificationLog = typeof verificationLogs.$inferSelect;
export type InsertVerificationLog = typeof verificationLogs.$inferInsert;
