import { useState } from "react";
import { Link, useLocation } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Upload,
  FileText,
  FileCheck,
  Users,
  LogOut,
  Shield,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/upload", label: "Upload", icon: Upload },
  { path: "/documents", label: "My Documents", icon: FileText },
];

const adminNavItems = [
  { path: "/verification", label: "Verification", icon: FileCheck },
  { path: "/admin", label: "Admin Panel", icon: Users },
];

export default function Sidebar({ isCollapsed, onToggleCollapse }: SidebarProps) {
  const location = useLocation();
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isAdmin = user?.role === "admin";

  const allNavItems = isAdmin ? [...navItems, ...adminNavItems] : navItems;

  const sidebarWidth = isCollapsed ? "w-[72px]" : "w-[260px]";

  const sidebarContent = (
    <>
      {/* ── Logo ── */}
      <div className="flex items-center gap-3 px-4 mb-10">
        <div className="w-8 h-8 rounded-lg bg-[#7c5cff] flex items-center justify-center flex-shrink-0">
          <Shield className="w-4 h-4 text-white" />
        </div>
        {!isCollapsed && (
          <span className="text-lg font-semibold text-white tracking-tight">DocuVault</span>
        )}
      </div>

      {/* ── Navigation ── */}
      <nav className="flex-1 px-2 space-y-1">
        {allNavItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setMobileOpen(false)}
              className={`
                flex items-center gap-3 h-11 px-3 rounded-[10px] transition-all duration-200 group
                ${isCollapsed ? "justify-center px-2" : ""}
                ${isActive
                  ? "bg-[rgba(124,92,255,0.15)] text-[#7c5cff]"
                  : "text-[rgba(255,255,255,0.7)] hover:bg-[rgba(255,255,255,0.04)] hover:text-white"
                }
              `}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!isCollapsed && (
                <span className="text-sm font-medium">{item.label}</span>
              )}
              {isCollapsed && (
                <div className="absolute left-full ml-2 px-2 py-1 bg-[#363640] rounded-md text-xs text-white opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                  {item.label}
                </div>
              )}
            </Link>
          );
        })}
      </nav>

      {/* ── User Profile ── */}
      <div className="mt-auto px-2 pt-4 border-t border-[rgba(255,255,255,0.08)]">
        <div className={`
          flex items-center gap-3 px-3 py-2 rounded-[10px]
          ${isCollapsed ? "justify-center" : ""}
        `}>
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#7c5cff] to-[#5a3fd1] flex items-center justify-center flex-shrink-0 text-sm font-medium text-white">
            {user?.name?.charAt(0)?.toUpperCase() || user?.email?.charAt(0)?.toUpperCase() || "U"}
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">
                {user?.name || "User"}
              </p>
              <p className="text-xs text-[rgba(255,255,255,0.45)] truncate">
                {isAdmin ? "Administrator" : "User"}
              </p>
            </div>
          )}
        </div>

        {/* ── Logout ── */}
        <Button
          variant="ghost"
          onClick={logout}
          className={`
            w-full mt-2 text-[rgba(255,255,255,0.45)] hover:text-[#f87171] hover:bg-[rgba(248,113,113,0.1)]
            ${isCollapsed ? "px-2 justify-center" : "justify-start gap-3 px-3"}
          `}
        >
          <LogOut className="w-4 h-4" />
          {!isCollapsed && <span className="text-sm">Logout</span>}
        </Button>
      </div>
    </>
  );

  return (
    <>
      {/* ── Mobile Hamburger ── */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-[60] w-10 h-10 rounded-lg bg-[#262630] border border-[rgba(255,255,255,0.08)] flex items-center justify-center text-white"
      >
        {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* ── Mobile Overlay ── */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setMobileOpen(false)}
            className="lg:hidden fixed inset-0 bg-black/60 z-[55] backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* ── Mobile Sidebar ── */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.aside
            initial={{ x: -260 }}
            animate={{ x: 0 }}
            exit={{ x: -260 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="lg:hidden fixed left-0 top-0 h-screen w-[260px] bg-[#262630] border-r border-[rgba(255,255,255,0.08)] z-[56] flex flex-col py-6"
          >
            {sidebarContent}
          </motion.aside>
        )}
      </AnimatePresence>

      {/* ── Desktop Sidebar ── */}
      <aside
        className={`
          hidden lg:flex fixed left-0 top-0 h-screen ${sidebarWidth}
          bg-[#262630] border-r border-[rgba(255,255,255,0.08)]
          flex-col py-6 transition-all duration-300 z-50
          ${isCollapsed ? "items-center" : ""}
        `}
      >
        {sidebarContent}

        {/* ── Collapse Toggle ── */}
        <button
          onClick={onToggleCollapse}
          className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-[#7c5cff] border border-[rgba(255,255,255,0.2)] flex items-center justify-center text-white hover:bg-[#6b4de8] transition-colors"
        >
          {isCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>
      </aside>
    </>
  );
}
