import { useState } from "react";
import { useLocation } from "react-router";
import { motion } from "framer-motion";
import { Search, Bell } from "lucide-react";
import Sidebar from "./Sidebar";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const pageTitles: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/upload": "Upload Document",
  "/documents": "My Documents",
  "/verification": "Verification Requests",
  "/admin": "Admin Dashboard",
  "/profile": "Profile",
};

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();
  const { user } = useAuth();

  const sidebarWidth = isCollapsed ? "lg:ml-[72px]" : "lg:ml-[260px]";
  const pageTitle = pageTitles[location.pathname] || "DocuVault";

  return (
    <div className="min-h-screen bg-[#0e0e14]">
      <Sidebar isCollapsed={isCollapsed} onToggleCollapse={() => setIsCollapsed(!isCollapsed)} />

      {/* ── Main Content ── */}
      <main className={`${sidebarWidth} transition-all duration-300 min-h-screen`}>
        {/* ── Header ── */}
        <header className="sticky top-0 z-40 h-16 bg-[#0e0e14]/80 backdrop-blur-xl border-b border-[rgba(255,255,255,0.08)] px-6 lg:px-10 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-white ml-12 lg:ml-0">{pageTitle}</h1>

          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[rgba(255,255,255,0.45)]" />
              <Input
                placeholder="Search..."
                className="w-64 pl-9 bg-[#262630] border-[rgba(255,255,255,0.08)] text-white placeholder:text-[rgba(255,255,255,0.45)] focus:border-[#7c5cff] focus:ring-[rgba(124,92,255,0.15)]"
              />
            </div>

            {/* Notifications */}
            <button className="relative w-10 h-10 rounded-lg bg-[#262630] border border-[rgba(255,255,255,0.08)] flex items-center justify-center text-[rgba(255,255,255,0.7)] hover:text-white transition-colors">
              <Bell className="w-4 h-4" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-[#7c5cff] rounded-full" />
            </button>

            {/* Avatar */}
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#7c5cff] to-[#5a3fd1] flex items-center justify-center text-sm font-medium text-white">
              {user?.name?.charAt(0)?.toUpperCase() || user?.email?.charAt(0)?.toUpperCase() || "U"}
            </div>
          </div>
        </header>

        {/* ── Page Content ── */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="p-6 lg:p-10"
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}
