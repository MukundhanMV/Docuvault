import { useRef, useEffect, useMemo } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";

// ── Configuration ──
const INSTANCE_COUNT = 8000;
const RING_COUNT = 6;
const RADIUS = 3.5;
const PALETTE = [
  new THREE.Color("#7c5cff").convertSRGBToLinear(),
  new THREE.Color("#4f3aba").convertSRGBToLinear(),
  new THREE.Color("#a78bfa").convertSRGBToLinear(),
  new THREE.Color("#262630").convertSRGBToLinear(),
  new THREE.Color("#1a1a24").convertSRGBToLinear(),
  new THREE.Color("#363640").convertSRGBToLinear(),
];

// ── Procedural Noise Texture ──
function createNoiseTexture(): THREE.DataTexture {
  const size = 256;
  const data = new Uint8Array(size * size * 4);
  for (let i = 0; i < size * size * 4; i += 4) {
    data[i] = Math.random() * 255;     // R - length
    data[i + 1] = Math.random() * 255; // G - radial offset
    data[i + 2] = Math.random() * 255; // B - color selection
    data[i + 3] = 255;                 // A
  }
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.needsUpdate = true;
  return texture;
}

// ── Vault Ring Component ──
function VaultRing() {
  const meshRef = useRef<THREE.InstancedMesh>(null!);
  const noiseTexture = useMemo(() => createNoiseTexture(), []);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  // Mouse and scroll state
  const scrollPos = useRef(0);
  const targetScrollPos = useRef(0);
  const mousePos = useRef({ x: 0, y: 0 });
  const targetMousePos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      targetScrollPos.current += e.deltaY * 0.0005;
    };

    const handleMouseMove = (e: MouseEvent) => {
      targetMousePos.current = {
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: (e.clientY / window.innerHeight) * 2 - 1,
      };
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        targetMousePos.current = {
          x: (e.touches[0].clientX / window.innerWidth) * 2 - 1,
          y: (e.touches[0].clientY / window.innerHeight) * 2 - 1,
        };
      }
    };

    window.addEventListener("wheel", handleWheel, { passive: false });
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("touchmove", handleTouchMove);

    return () => {
      window.removeEventListener("wheel", handleWheel);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("touchmove", handleTouchMove);
    };
  }, []);

  // Initialize instance matrices
  useEffect(() => {
    if (!meshRef.current) return;

    const mesh = meshRef.current;
    const imageData = noiseTexture.image?.data;
    const texSize = 256;
    if (!imageData) return;

    let idx = 0;
    for (let ring = 0; ring < RING_COUNT; ring++) {
      const ringRadius = RADIUS * (0.4 + ring * 0.3);
      const ringCount = Math.floor(INSTANCE_COUNT / RING_COUNT);

      for (let i = 0; i < ringCount; i++) {
        const angle = (i / ringCount) * Math.PI * 2 + ring * 0.5;

        // Read noise values
        const nx = Math.floor(((Math.cos(angle) + 1) / 2) * (texSize - 1));
        const ny = Math.floor(((Math.sin(angle) + 1) / 2) * (texSize - 1));
        const pixelIdx = (ny * texSize + nx) * 4;

        const noiseR = imageData[pixelIdx] / 255;
        const noiseG = imageData[pixelIdx + 1] / 255;
        const noiseB = imageData[pixelIdx + 2] / 255;

        // Length from noise
        const len = 0.3 + noiseR * 2.5;

        // Radial offset from noise
        const offset = (noiseG - 0.5) * 0.4;

        // Position on ring
        const x = Math.cos(angle) * (ringRadius + offset);
        const z = Math.sin(angle) * (ringRadius + offset);
        const y = (noiseB - 0.5) * 3;

        dummy.position.set(x, y, z);
        dummy.rotation.set(
          Math.random() * 0.3,
          angle,
          Math.random() * 0.3
        );
        dummy.scale.set(1, len, 1);
        dummy.updateMatrix();
        mesh.setMatrixAt(idx, dummy.matrix);

        // Set color from palette
        const colorIdx = Math.floor(noiseB * PALETTE.length) % PALETTE.length;
        mesh.setColorAt(idx, PALETTE[colorIdx]);

        idx++;
      }
    }

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [noiseTexture, dummy]);

  // Animation loop
  const { camera } = useThree();

  useFrame(() => {
    if (!meshRef.current) return;

    // Smooth scroll lerp
    scrollPos.current += (targetScrollPos.current - scrollPos.current) * 0.05;

    // Smooth mouse lerp
    mousePos.current.x += (targetMousePos.current.x - mousePos.current.x) * 0.05;
    mousePos.current.y += (targetMousePos.current.y - mousePos.current.y) * 0.05;

    // Auto-rotation
    meshRef.current.rotation.y += 0.001;

    // Scroll-driven tilt
    meshRef.current.rotation.x = scrollPos.current * 0.5;

    // Camera parallax from mouse
    camera.position.x = mousePos.current.x * 1.5;
    camera.position.y = -mousePos.current.y * 0.8;
    camera.lookAt(0, 0, 0);
  });

  return (
    <>
      <instancedMesh ref={meshRef} args={[undefined, undefined, INSTANCE_COUNT]}>
        <cylinderGeometry args={[0.03, 0.03, 1, 16]} />
        <meshPhysicalMaterial
          metalness={0.1}
          roughness={0.2}
          transmission={0.6}
          thickness={0.5}
          clearcoat={1.0}
          clearcoatRoughness={0.1}
          transparent
        />
      </instancedMesh>
      <pointLight position={[5, 5, 5]} intensity={1.5} color="#7c5cff" />
      <pointLight position={[-5, -3, -5]} intensity={0.8} color="#a78bfa" />
      <ambientLight intensity={0.3} />
    </>
  );
}

// ── Main VaultWheel Component ──
export default function VaultWheel() {
  return (
    <div className="fixed inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 8], fov: 60 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "#0e0e14" }}
      >
        <VaultRing />
        <EffectComposer>
          <Bloom
            intensity={0.4}
            luminanceThreshold={0.85}
            luminanceSmoothing={0.1}
            mipmapBlur
          />
        </EffectComposer>
      </Canvas>
    </div>
  );
}
