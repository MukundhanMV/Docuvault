import type { LucideIcon } from "lucide-react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import {
  FileText,
  FileCheck,
  Clock,
  Shield,
  Download,
  Trash2,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from "lucide-react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { trpc } from "@/providers/trpc";
import { Skeleton } from "@/components/ui/skeleton";

// ── Stat Card ──
function StatCard({
  icon: Icon,
  value,
  label,
  trend,
  trendType,
  tint,
}: {
  icon: LucideIcon;
  value: string | number;
  label: string;
  trend: string;
  trendType: "up" | "down" | "neutral";
  tint: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6 hover:-translate-y-0.5 hover:border-[rgba(124,92,255,0.2)] transition-all duration-300"
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center"
        style={{ backgroundColor: `${tint}18` }}
      >
        <Icon className="w-5 h-5" style={{ color: tint }} />
      </div>
      <p className="text-[32px] font-semibold text-white mt-4 leading-10 tracking-tight">{value}</p>
      <p className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide mt-1">{label}</p>
      <div className="flex items-center gap-1 mt-3">
        {trendType === "up" && <ArrowUpRight className="w-3.5 h-3.5 text-[#4ade80]" />}
        {trendType === "down" && <ArrowDownRight className="w-3.5 h-3.5 text-[#f87171]" />}
        {trendType === "neutral" && <Minus className="w-3.5 h-3.5 text-[#fbbf24]" />}
        <span
          className="text-xs"
          style={{
            color: trendType === "up" ? "#4ade80" : trendType === "down" ? "#f87171" : "#fbbf24",
          }}
        >
          {trend}
        </span>
      </div>
    </motion.div>
  );
}

// ── Status Badge ──
function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, { bg: string; color: string }> = {
    verified: { bg: "rgba(74,222,128,0.15)", color: "#4ade80" },
    pending: { bg: "rgba(251,191,36,0.15)", color: "#fbbf24" },
    rejected: { bg: "rgba(248,113,113,0.15)", color: "#f87171" },
  };
  const style = styles[status] || styles.pending;

  return (
    <span
      className="inline-flex px-3 py-1 rounded-full text-xs font-medium"
      style={{ backgroundColor: style.bg, color: style.color }}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

// ── Recent Documents Table ──
function RecentDocuments() {
  const { data, isLoading } = trpc.document.list.useQuery({ page: 1, limit: 5, sort: "created_at_desc" });
  const utils = trpc.useUtils();
  const deleteMutation = trpc.document.delete.useMutation({
    onSuccess: () => {
      utils.document.list.invalidate();
      utils.document.stats.invalidate();
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-14 bg-[rgba(255,255,255,0.05)]" />
        ))}
      </div>
    );
  }

  const docs = data?.documents || [];

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-[rgba(255,255,255,0.08)]">
            {["Document", "Category", "Date", "Status", "Actions"].map((h) => (
              <th key={h} className="text-left py-3 px-4 text-xs font-medium uppercase tracking-wide text-[rgba(255,255,255,0.45)]">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {docs.length === 0 ? (
            <tr>
              <td colSpan={5} className="py-12 text-center text-sm text-[rgba(255,255,255,0.45)]">
                No documents yet. Upload your first document!
              </td>
            </tr>
          ) : (
            docs.map((doc) => (
              <tr
                key={doc.id}
                className="border-b border-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.02)] transition-colors"
              >
                <td className="py-4 px-4">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-[rgba(255,255,255,0.45)] flex-shrink-0" />
                    <span className="text-sm text-white truncate max-w-[200px]">{doc.title}</span>
                  </div>
                </td>
                <td className="py-4 px-4">
                  <span className="text-xs text-[rgba(255,255,255,0.45)] capitalize">{doc.category}</span>
                </td>
                <td className="py-4 px-4">
                  <span className="text-xs text-[rgba(255,255,255,0.45)]">
                    {doc.createdAt ? new Date(doc.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—"}
                  </span>
                </td>
                <td className="py-4 px-4">
                  <StatusBadge status={doc.status} />
                </td>
                <td className="py-4 px-4">
                  <div className="flex items-center gap-2">
                    <button className="w-8 h-8 rounded-lg flex items-center justify-center text-[rgba(255,255,255,0.45)] hover:text-white hover:bg-[rgba(255,255,255,0.05)] transition-colors">
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteMutation.mutate({ id: doc.id })}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-[rgba(255,255,255,0.45)] hover:text-[#f87171] hover:bg-[rgba(248,113,113,0.1)] transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

// ── Activity Feed ──
function ActivityFeed() {
  const { data, isLoading } = trpc.activity.list.useQuery({ limit: 5 });

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-10 bg-[rgba(255,255,255,0.05)]" />
        ))}
      </div>
    );
  }

  const activities = data || [];

  function getActionInfo(action: string) {
    const icons: Record<string, { icon: LucideIcon; color: string }> = {
      upload: { icon: FileText, color: "#7c5cff" },
      verify: { icon: FileCheck, color: "#4ade80" },
      reject: { icon: Clock, color: "#f87171" },
      delete: { icon: Trash2, color: "#f87171" },
      login: { icon: Shield, color: "#7c5cff" },
    };
    return icons[action] || icons.login;
  }

  return (
    <div className="space-y-0">
      {activities.length === 0 ? (
        <p className="text-sm text-[rgba(255,255,255,0.45)] py-8 text-center">No recent activity</p>
      ) : (
        activities.map((activity) => {
          const actionInfo = getActionInfo(activity.action);
          const Icon = actionInfo.icon;
          return (
            <div
              key={activity.id}
              className="flex items-start gap-3 py-3 border-b border-[rgba(255,255,255,0.04)] last:border-0"
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ backgroundColor: `${actionInfo.color}18` }}
              >
                <Icon className="w-3.5 h-3.5" style={{ color: actionInfo.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-[rgba(255,255,255,0.7)]">{activity.details || activity.action}</p>
                <p className="text-xs text-[rgba(255,255,255,0.45)] mt-0.5">
                  {activity.createdAt
                    ? new Date(activity.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })
                    : "—"}
                </p>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = trpc.document.stats.useQuery();

  const statCards = [
    { icon: FileText, value: stats?.total ?? 0, label: "Total Documents", trend: "+12% this month", trendType: "up" as const, tint: "#7c5cff" },
    { icon: FileCheck, value: stats?.verified ?? 0, label: "Verified", trend: "+8% this month", trendType: "up" as const, tint: "#4ade80" },
    { icon: Clock, value: stats?.pending ?? 0, label: "Pending", trend: "2 new today", trendType: "neutral" as const, tint: "#fbbf24" },
    { icon: Shield, value: statsLoading ? "..." : "100%", label: "Security Score", trend: "Optimal", trendType: "up" as const, tint: "#7c5cff" },
  ];

  return (
    <DashboardLayout>
      {/* ── Stats Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {statCards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <StatCard {...card} />
          </motion.div>
        ))}
      </div>

      {/* ── Main Content Grid ── */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
        {/* ── Recent Documents ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-medium text-white">Recent Uploads</h2>
            <Link
              to="/documents"
              className="text-sm text-[#7c5cff] hover:underline flex items-center gap-1"
            >
              View All
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <RecentDocuments />
        </motion.div>

        {/* ── Activity Feed ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6"
        >
          <h2 className="text-lg font-medium text-white mb-6">Recent Activity</h2>
          <ActivityFeed />
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
