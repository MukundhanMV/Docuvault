import { Link } from "react-router";
import { motion } from "framer-motion";
import { Shield, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0e0e14] flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        {/* Logo */}
        <Link to="/" className="inline-flex items-center gap-2 mb-12">
          <div className="w-8 h-8 rounded-md bg-[#7c5cff] flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <span className="text-lg font-semibold text-white tracking-tight">DocuVault</span>
        </Link>

        {/* 404 */}
        <h1 className="text-[120px] font-semibold text-[rgba(124,92,255,0.15)] leading-none tracking-tighter">
          404
        </h1>
        <h2 className="text-2xl font-medium text-white mt-4">Page not found</h2>
        <p className="text-base text-[rgba(255,255,255,0.7)] mt-3 max-w-md mx-auto">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>

        {/* CTA */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 mt-8 px-6 py-3 bg-[#7c5cff] hover:bg-[#6b4de8] text-white font-medium rounded-xl transition-all duration-200 hover:scale-[1.02]"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
      </motion.div>
    </div>
  );
}
