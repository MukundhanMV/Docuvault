import { useState } from "react";
import { motion } from "framer-motion";
import {
  FileText,
  Download,
  Trash2,
  Search,
  SlidersHorizontal,
  File,
  Image,
} from "lucide-react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { trpc } from "@/providers/trpc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

// ── Status Badge ──
function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, { bg: string; color: string }> = {
    verified: { bg: "rgba(74,222,128,0.15)", color: "#4ade80" },
    pending: { bg: "rgba(251,191,36,0.15)", color: "#fbbf24" },
    rejected: { bg: "rgba(248,113,113,0.15)", color: "#f87171" },
  };
  const style = styles[status] || styles.pending;

  return (
    <span
      className="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium"
      style={{ backgroundColor: style.bg, color: style.color }}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

// ── Document Card ──
function DocumentCard({
  doc,
  onDelete,
}: {
  doc: {
    id: number;
    title: string;
    category: string;
    status: string;
    fileName: string;
    fileType: string;
    fileSize: number;
    createdAt: Date | null;
  };
  onDelete: (id: number) => void;
}) {
  const [isHovered, setIsHovered] = useState(false);

  const getFileIcon = () => {
    if (doc.fileType.startsWith("image/")) return <Image className="w-10 h-10 text-[rgba(255,255,255,0.25)]" />;
    return <File className="w-10 h-10 text-[rgba(255,255,255,0.25)]" />;
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl overflow-hidden hover:-translate-y-1 hover:border-[rgba(124,92,255,0.2)] transition-all duration-300 group"
    >
      {/* Thumbnail */}
      <div className="h-[160px] bg-[rgba(255,255,255,0.02)] flex items-center justify-center relative">
        {getFileIcon()}
        {isHovered && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-[rgba(14,14,20,0.6)] flex items-center justify-center gap-3"
          >
            <button className="w-9 h-9 rounded-lg bg-[rgba(255,255,255,0.1)] flex items-center justify-center text-white hover:bg-[#7c5cff] transition-colors">
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(doc.id)}
              className="w-9 h-9 rounded-lg bg-[rgba(255,255,255,0.1)] flex items-center justify-center text-white hover:bg-[#f87171] transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-sm font-medium text-white truncate" title={doc.title}>
          {doc.title}
        </h3>
        <div className="flex items-center gap-2 mt-2">
          <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-[rgba(124,92,255,0.1)] text-[#7c5cff] capitalize">
            {doc.category}
          </span>
          <span className="text-xs text-[rgba(255,255,255,0.45)]">{formatSize(doc.fileSize)}</span>
        </div>
        <div className="flex items-center justify-between mt-3">
          <StatusBadge status={doc.status} />
          <span className="text-xs text-[rgba(255,255,255,0.45)]">
            {doc.createdAt
              ? new Date(doc.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })
              : "—"}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

export default function DocumentsPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("created_at_desc");
  const [deleteDoc, setDeleteDoc] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.document.list.useQuery({
    search: search || undefined,
    category: category !== "all" ? (category as "legal" | "finance" | "identity" | "medical" | "education" | "other") : undefined,
    status: status !== "all" ? (status as "pending" | "verified" | "rejected") : undefined,
    sort,
    page: 1,
    limit: 50,
  });

  const deleteMutation = trpc.document.delete.useMutation({
    onSuccess: () => {
      utils.document.list.invalidate();
      utils.document.stats.invalidate();
      utils.activity.list.invalidate();
      toast.success("Document deleted successfully");
      setDeleteDoc(null);
    },
    onError: () => {
      toast.error("Failed to delete document");
    },
  });

  const handleDelete = (id: number) => {
    setDeleteDoc(id);
  };

  const confirmDelete = () => {
    if (deleteDoc) {
      deleteMutation.mutate({ id: deleteDoc });
    }
  };

  const documents = data?.documents || [];

  return (
    <DashboardLayout>
      <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
        My Documents
      </h2>
      <p className="text-base text-[rgba(255,255,255,0.7)] mt-2 mb-8">
        Manage and organize all your documents
      </p>

      {/* ── Filter Bar ── */}
      <div className="bg-[#262630] rounded-2xl p-4 mb-6 flex flex-col lg:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[rgba(255,255,255,0.45)]" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search documents..."
            className="pl-9 h-10 bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white placeholder:text-[rgba(255,255,255,0.45)] focus:border-[#7c5cff]"
          />
        </div>

        <div className="flex gap-3 flex-wrap">
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-[140px] h-10 bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white">
              <SlidersHorizontal className="w-3.5 h-3.5 mr-2 text-[rgba(255,255,255,0.45)]" />
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent className="bg-[#262630] border-[rgba(255,255,255,0.08)]">
              <SelectItem value="all" className="text-white focus:bg-[rgba(124,92,255,0.15)]">All Categories</SelectItem>
              <SelectItem value="legal" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Legal</SelectItem>
              <SelectItem value="finance" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Finance</SelectItem>
              <SelectItem value="identity" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Identity</SelectItem>
              <SelectItem value="medical" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Medical</SelectItem>
              <SelectItem value="education" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Education</SelectItem>
              <SelectItem value="other" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Other</SelectItem>
            </SelectContent>
          </Select>

          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-[130px] h-10 bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white">
              <FileText className="w-3.5 h-3.5 mr-2 text-[rgba(255,255,255,0.45)]" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="bg-[#262630] border-[rgba(255,255,255,0.08)]">
              <SelectItem value="all" className="text-white focus:bg-[rgba(124,92,255,0.15)]">All Status</SelectItem>
              <SelectItem value="verified" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Verified</SelectItem>
              <SelectItem value="pending" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Pending</SelectItem>
              <SelectItem value="rejected" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Rejected</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-[130px] h-10 bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white">
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent className="bg-[#262630] border-[rgba(255,255,255,0.08)]">
              <SelectItem value="created_at_desc" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Newest</SelectItem>
              <SelectItem value="created_at_asc" className="text-white focus:bg-[rgba(124,92,255,0.15)]">Oldest</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* ── Results Count ── */}
      <p className="text-sm text-[rgba(255,255,255,0.45)] mb-4">
        {isLoading ? "Loading..." : `${documents.length} document${documents.length !== 1 ? "s" : ""} found`}
      </p>

      {/* ── Document Grid ── */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="rounded-2xl overflow-hidden">
              <Skeleton className="h-[160px] bg-[rgba(255,255,255,0.05)]" />
              <div className="p-5 space-y-3">
                <Skeleton className="h-4 w-3/4 bg-[rgba(255,255,255,0.05)]" />
                <Skeleton className="h-3 w-1/2 bg-[rgba(255,255,255,0.05)]" />
              </div>
            </div>
          ))}
        </div>
      ) : documents.length === 0 ? (
        <div className="text-center py-20">
          <FileText className="w-12 h-12 text-[rgba(255,255,255,0.25)] mx-auto mb-4" />
          <p className="text-lg text-[rgba(255,255,255,0.7)]">No documents found</p>
          <p className="text-sm text-[rgba(255,255,255,0.45)] mt-1">
            Try adjusting your filters or upload a new document
          </p>
        </div>
      ) : (
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {documents.map((doc) => (
            <DocumentCard key={doc.id} doc={doc} onDelete={handleDelete} />
          ))}
        </motion.div>
      )}

      {/* ── Delete Confirmation Dialog ── */}
      <Dialog open={!!deleteDoc} onOpenChange={() => setDeleteDoc(null)}>
        <DialogContent className="bg-[#262630] border-[rgba(255,255,255,0.08)] text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Document</DialogTitle>
            <DialogDescription className="text-[rgba(255,255,255,0.7)]">
              Are you sure you want to delete this document? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 justify-end mt-4">
            <Button
              variant="ghost"
              onClick={() => setDeleteDoc(null)}
              className="text-[rgba(255,255,255,0.7)] hover:text-white"
            >
              Cancel
            </Button>
            <Button
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
              className="bg-[#f87171] hover:bg-[#e55c5c] text-white"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
