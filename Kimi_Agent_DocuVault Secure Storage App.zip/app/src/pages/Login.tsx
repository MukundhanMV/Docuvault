import { useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "framer-motion";
import { Shield, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (user && !isLoading) {
      navigate("/dashboard");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0e0e14] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#7c5cff] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0e0e14] flex items-center justify-center px-6 relative overflow-hidden">
      {/* Background gradient */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 50% 50%, rgba(124,92,255,0.08) 0%, transparent 60%)",
        }}
      />

      {/* Floating orbs */}
      <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-[#7c5cff] rounded-full opacity-[0.03] blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#7c5cff] rounded-full opacity-[0.02] blur-[120px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-[420px] relative z-10"
      >
        {/* Card */}
        <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-10 card-shadow">
          {/* Logo */}
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-[#7c5cff] flex items-center justify-center">
              <Shield className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-lg font-semibold text-white tracking-tight">DocuVault</span>
          </Link>

          {/* Heading */}
          <div className="mt-8">
            <h1 className="text-[28px] font-medium text-white leading-9 tracking-tight">
              Welcome back
            </h1>
            <p className="text-base text-[rgba(255,255,255,0.7)] mt-2">
              Sign in to your secure vault
            </p>
          </div>

          {/* ── Kimi OAuth Button ── */}
          <button
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
            className="w-full mt-8 h-12 bg-[#7c5cff] hover:bg-[#6b4de8] text-white font-medium rounded-xl flex items-center justify-center gap-2 transition-all duration-200 hover:scale-[1.02]"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.418 0-8-3.582-8-8s3.582-8 8-8 8 3.582 8 8-3.582 8-8 8z" />
              <path d="M12 6c-3.314 0-6 2.686-6 6s2.686 6 6 6 6-2.686 6-6-2.686-6-6-6zm0 10c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z" />
            </svg>
            Continue with Kimi
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Divider */}
          <div className="flex items-center gap-4 mt-8">
            <div className="flex-1 h-px bg-[rgba(255,255,255,0.08)]" />
            <span className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide">or</span>
            <div className="flex-1 h-px bg-[rgba(255,255,255,0.08)]" />
          </div>

          {/* ── Guest Access ── */}
          <button
            onClick={() => {
              toast.info("Please use the Kimi login button to authenticate.");
            }}
            className="w-full mt-6 h-12 border border-[rgba(255,255,255,0.08)] hover:border-[rgba(255,255,255,0.15)] bg-transparent text-[rgba(255,255,255,0.7)] font-medium rounded-xl flex items-center justify-center gap-2 transition-all duration-200"
          >
            Sign in as Guest
          </button>

          {/* Footer */}
          <p className="text-sm text-[rgba(255,255,255,0.45)] text-center mt-8">
            Don&apos;t have an account?{" "}
            <button
              onClick={() => {
                window.location.href = getOAuthUrl();
              }}
              className="text-[#7c5cff] hover:underline font-medium"
            >
              Get Started
            </button>
          </p>
        </div>

        {/* Back to home */}
        <div className="text-center mt-6">
          <Link
            to="/"
            className="text-sm text-[rgba(255,255,255,0.45)] hover:text-white transition-colors"
          >
            Back to home
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
