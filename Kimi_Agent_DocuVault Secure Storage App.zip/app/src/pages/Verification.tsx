import { useState } from "react";
import type { LucideIcon } from "lucide-react";
import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import {
  Clock,
  CheckCircle,
  XCircle,
  FileText,
  Check,
  X,
  Eye,
} from "lucide-react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

// ── Stat Card ──
function StatCard({
  icon: Icon,
  value,
  label,
  tint,
}: {
  icon: LucideIcon;
  value: string | number;
  label: string;
  tint: string;
}) {
  return (
    <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${tint}18` }}>
        <Icon className="w-5 h-5" style={{ color: tint }} />
      </div>
      <p className="text-[32px] font-semibold text-white mt-4 leading-10">{value}</p>
      <p className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide mt-1">{label}</p>
    </div>
  );
}

// ── Status Badge ──
function StatusBadge({ status }: { status: "verified" | "pending" | "rejected" }) {
  const styles = {
    verified: { bg: "rgba(74,222,128,0.15)", color: "#4ade80" },
    pending: { bg: "rgba(251,191,36,0.15)", color: "#fbbf24" },
    rejected: { bg: "rgba(248,113,113,0.15)", color: "#f87171" },
  };
  const style = styles[status] || styles.pending;

  return (
    <span
      className="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium"
      style={{ backgroundColor: style.bg, color: style.color }}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export default function VerificationPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [viewDoc, setViewDoc] = useState<number | null>(null);

  // Redirect non-admin users
  if (user && user.role !== "admin") {
    navigate("/dashboard");
    return null;
  }

  const utils = trpc.useUtils();
  const { data: stats, isLoading: statsLoading } = trpc.verification.stats.useQuery();
  const { data: pendingData, isLoading: pendingLoading } = trpc.verification.pending.useQuery({ page: 1, limit: 20 });

  const verifyMutation = trpc.document.verify.useMutation({
    onSuccess: () => {
      utils.verification.pending.invalidate();
      utils.verification.stats.invalidate();
      utils.document.list.invalidate();
      utils.activity.list.invalidate();
      toast.success("Document verified successfully");
    },
    onError: () => {
      toast.error("Failed to verify document");
    },
  });

  const rejectMutation = trpc.document.verify.useMutation({
    onSuccess: () => {
      utils.verification.pending.invalidate();
      utils.verification.stats.invalidate();
      utils.document.list.invalidate();
      utils.activity.list.invalidate();
      toast.success("Document rejected");
    },
    onError: () => {
      toast.error("Failed to reject document");
    },
  });

  const handleApprove = (id: number) => {
    verifyMutation.mutate({ id, status: "verified" });
  };

  const handleReject = (id: number) => {
    rejectMutation.mutate({ id, status: "rejected", reason: "Does not meet requirements" });
  };

  const pendingDocs = pendingData?.documents || [];

  // View document
  const { data: viewDocument } = trpc.document.getById.useQuery(
    { id: viewDoc! },
    { enabled: !!viewDoc }
  );

  return (
    <DashboardLayout>
      <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
        Verification Requests
      </h2>
      <p className="text-base text-[rgba(255,255,255,0.7)] mt-2 mb-8">
        Review and approve document submissions
      </p>

      {/* ── Stats Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        {statsLoading ? (
          <>
            <Skeleton className="h-[140px] bg-[rgba(255,255,255,0.05)] rounded-2xl" />
            <Skeleton className="h-[140px] bg-[rgba(255,255,255,0.05)] rounded-2xl" />
            <Skeleton className="h-[140px] bg-[rgba(255,255,255,0.05)] rounded-2xl" />
          </>
        ) : (
          <>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
              <StatCard icon={Clock} value={stats?.pending ?? 0} label="Pending Review" tint="#fbbf24" />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <StatCard icon={CheckCircle} value={stats?.approvedToday ?? 0} label="Approved Today" tint="#4ade80" />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <StatCard icon={XCircle} value={stats?.rejectedThisWeek ?? 0} label="Rejected This Week" tint="#f87171" />
            </motion.div>
          </>
        )}
      </div>

      {/* ── Pending Documents Table ── */}
      <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6">
        <h3 className="text-lg font-medium text-white mb-6">Pending Documents</h3>

        {pendingLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-14 bg-[rgba(255,255,255,0.05)]" />
            ))}
          </div>
        ) : pendingDocs.length === 0 ? (
          <div className="text-center py-16">
            <CheckCircle className="w-12 h-12 text-[#4ade80] mx-auto mb-4" />
            <p className="text-lg text-white">All caught up!</p>
            <p className="text-sm text-[rgba(255,255,255,0.45)] mt-1">No pending verification requests</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[rgba(255,255,255,0.08)]">
                  {["Document", "Category", "Uploaded", "Status", "Actions"].map((h) => (
                    <th key={h} className="text-left py-3 px-4 text-xs font-medium uppercase tracking-wide text-[rgba(255,255,255,0.45)]">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pendingDocs.map((doc) => (
                  <tr
                    key={doc.id}
                    className="border-b border-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.02)] transition-colors"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <FileText className="w-4 h-4 text-[rgba(255,255,255,0.45)] flex-shrink-0" />
                        <span className="text-sm text-white truncate max-w-[200px]">{doc.title}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-xs text-[rgba(255,255,255,0.45)] capitalize">{doc.category}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-xs text-[rgba(255,255,255,0.45)]">
                        {doc.createdAt
                          ? new Date(doc.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })
                          : "—"}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <StatusBadge status={doc.status} />
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApprove(doc.id)}
                          disabled={verifyMutation.isPending}
                          className="bg-[rgba(74,222,128,0.15)] text-[#4ade80] border border-[#4ade80] hover:bg-[rgba(74,222,128,0.25)] h-8 px-3 text-xs"
                        >
                          <Check className="w-3.5 h-3.5 mr-1" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleReject(doc.id)}
                          disabled={rejectMutation.isPending}
                          variant="outline"
                          className="bg-[rgba(248,113,113,0.15)] text-[#f87171] border border-[#f87171] hover:bg-[rgba(248,113,113,0.25)] h-8 px-3 text-xs"
                        >
                          <X className="w-3.5 h-3.5 mr-1" />
                          Reject
                        </Button>
                        <button
                          onClick={() => setViewDoc(doc.id)}
                          className="w-8 h-8 rounded-lg flex items-center justify-center text-[#7c5cff] hover:bg-[rgba(124,92,255,0.1)] transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── View Document Dialog ── */}
      <Dialog open={!!viewDoc} onOpenChange={() => setViewDoc(null)}>
        <DialogContent className="bg-[#262630] border-[rgba(255,255,255,0.08)] text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-lg">Document Details</DialogTitle>
          </DialogHeader>
          {viewDocument && (
            <div className="space-y-4">
              <div>
                <p className="text-xs text-[rgba(255,255,255,0.45)] uppercase tracking-wide">Title</p>
                <p className="text-sm text-white mt-1">{viewDocument.title}</p>
              </div>
              <div>
                <p className="text-xs text-[rgba(255,255,255,0.45)] uppercase tracking-wide">Category</p>
                <p className="text-sm text-white mt-1 capitalize">{viewDocument.category}</p>
              </div>
              {viewDocument.description && (
                <div>
                  <p className="text-xs text-[rgba(255,255,255,0.45)] uppercase tracking-wide">Description</p>
                  <p className="text-sm text-white mt-1">{viewDocument.description}</p>
                </div>
              )}
              <div>
                <p className="text-xs text-[rgba(255,255,255,0.45)] uppercase tracking-wide">File</p>
                <p className="text-sm text-white mt-1">{viewDocument.fileName}</p>
              </div>
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={() => { handleApprove(viewDocument.id); setViewDoc(null); }}
                  className="flex-1 bg-[rgba(74,222,128,0.15)] text-[#4ade80] border border-[#4ade80] hover:bg-[rgba(74,222,128,0.25)]"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Approve
                </Button>
                <Button
                  onClick={() => { handleReject(viewDocument.id); setViewDoc(null); }}
                  variant="outline"
                  className="flex-1 bg-[rgba(248,113,113,0.15)] text-[#f87171] border border-[#f87171] hover:bg-[rgba(248,113,113,0.25)]"
                >
                  <X className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
