import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import {
  Users,
  FileText,
  Clock,
  FileCheck,
  UserCheck,
  UserX,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

// ── Stat Card ──
function StatCard({
  icon: Icon,
  value,
  label,
  tint,
}: {
  icon: LucideIcon;
  value: string | number;
  label: string;
  tint: string;
}) {
  return (
    <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6 hover:-translate-y-0.5 hover:border-[rgba(124,92,255,0.2)] transition-all duration-300">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${tint}18` }}>
        <Icon className="w-5 h-5" style={{ color: tint }} />
      </div>
      <p className="text-[32px] font-semibold text-white mt-4 leading-10">{value}</p>
      <p className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide mt-1">{label}</p>
    </div>
  );
}

// ── Mock chart data ──
const uploadTrendData = [
  { day: "May 1", uploads: 12 },
  { day: "May 3", uploads: 19 },
  { day: "May 5", uploads: 8 },
  { day: "May 7", uploads: 25 },
  { day: "May 9", uploads: 15 },
  { day: "May 11", uploads: 32 },
  { day: "May 13", uploads: 20 },
  { day: "May 15", uploads: 18 },
  { day: "May 17", uploads: 28 },
  { day: "May 19", uploads: 22 },
];

const categoryData = [
  { category: "Legal", count: 45 },
  { category: "Finance", count: 78 },
  { category: "Identity", count: 32 },
  { category: "Medical", count: 28 },
  { category: "Education", count: 56 },
  { category: "Other", count: 15 },
];

// ── Status Badge ──
function StatusBadge({ status, type }: { status: string; type: "user" | "doc" }) {
  if (type === "user") {
    const isActive = status === "active";
    return (
      <span
        className="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium"
        style={{
          backgroundColor: isActive ? "rgba(74,222,128,0.15)" : "rgba(255,255,255,0.08)",
          color: isActive ? "#4ade80" : "rgba(255,255,255,0.45)",
        }}
      >
        {isActive ? "Active" : "Inactive"}
      </span>
    );
  }

  const styles: Record<string, { bg: string; color: string }> = {
    verified: { bg: "rgba(74,222,128,0.15)", color: "#4ade80" },
    pending: { bg: "rgba(251,191,36,0.15)", color: "#fbbf24" },
    rejected: { bg: "rgba(248,113,113,0.15)", color: "#f87171" },
  };
  const style = styles[status] || styles.pending;

  return (
    <span
      className="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium"
      style={{ backgroundColor: style.bg, color: style.color }}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export default function AdminPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [userPage, setUserPage] = useState(1);

  // Redirect non-admin users
  if (user && user.role !== "admin") {
    navigate("/dashboard");
    return null;
  }

  const utils = trpc.useUtils();
  const { data: userStats, isLoading: statsLoading } = trpc.user.stats.useQuery();
  const { data: verificationStats } = trpc.verification.stats.useQuery();
  const { data: usersData, isLoading: usersLoading } = trpc.user.list.useQuery({ page: userPage, limit: 10 });
  const { data: documentsData } = trpc.document.adminList.useQuery({ page: 1, limit: 5 });

  const updateRoleMutation = trpc.user.updateRole.useMutation({
    onSuccess: () => {
      utils.user.list.invalidate();
      utils.user.stats.invalidate();
      toast.success("User role updated");
    },
  });

  const updateStatusMutation = trpc.user.updateStatus.useMutation({
    onSuccess: () => {
      utils.user.list.invalidate();
      utils.user.stats.invalidate();
      toast.success("User status updated");
    },
  });

  return (
    <DashboardLayout>
      <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
        Admin Dashboard
      </h2>
      <p className="text-base text-[rgba(255,255,255,0.7)] mt-2 mb-8">
        Platform overview and user management
      </p>

      {/* ── Stats Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {statsLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-[140px] bg-[rgba(255,255,255,0.05)] rounded-2xl" />
          ))
        ) : (
          <>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
              <StatCard icon={Users} value={userStats?.totalUsers ?? 0} label="Total Users" tint="#7c5cff" />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <StatCard icon={FileText} value={userStats?.totalDocuments ?? 0} label="Total Documents" tint="#7c5cff" />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <StatCard icon={Clock} value={verificationStats?.pending ?? 0} label="Pending Verifications" tint="#fbbf24" />
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
              <StatCard icon={FileCheck} value={userStats?.totalDocuments ? userStats.totalDocuments - (verificationStats?.pending ?? 0) : 0} label="Verified Documents" tint="#4ade80" />
            </motion.div>
          </>
        )}
      </div>

      {/* ── Charts ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Upload Trend */}
        <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6">
          <h3 className="text-lg font-medium text-white mb-6">Document Upload Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={uploadTrendData}>
              <defs>
                <linearGradient id="uploadGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7c5cff" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#7c5cff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="day" tick={{ fill: "rgba(255,255,255,0.45)", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.45)", fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#262630",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "12px",
                  color: "#fff",
                  fontSize: "12px",
                }}
              />
              <Area type="monotone" dataKey="uploads" stroke="#7c5cff" strokeWidth={2} fill="url(#uploadGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Documents by Category */}
        <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6">
          <h3 className="text-lg font-medium text-white mb-6">Documents by Category</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="category" tick={{ fill: "rgba(255,255,255,0.45)", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.45)", fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#262630",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "12px",
                  color: "#fff",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="count" fill="#7c5cff" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── User Management Table ── */}
      <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6 mb-8">
        <h3 className="text-lg font-medium text-white mb-6">User Management</h3>

        {usersLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-14 bg-[rgba(255,255,255,0.05)]" />
            ))}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[rgba(255,255,255,0.08)]">
                    {["User", "Email", "Role", "Documents", "Joined", "Status", "Actions"].map((h) => (
                      <th key={h} className="text-left py-3 px-4 text-xs font-medium uppercase tracking-wide text-[rgba(255,255,255,0.45)]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {usersData?.users.map((u) => (
                    <tr
                      key={u.id}
                      className="border-b border-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.02)] transition-colors"
                    >
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#7c5cff] to-[#5a3fd1] flex items-center justify-center text-sm font-medium text-white flex-shrink-0">
                            {u.name?.charAt(0)?.toUpperCase() || u.email?.charAt(0)?.toUpperCase() || "U"}
                          </div>
                          <span className="text-sm text-white">{u.name || "Unnamed"}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className="text-sm text-[rgba(255,255,255,0.7)]">{u.email}</span>
                      </td>
                      <td className="py-4 px-4">
                        <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium ${u.role === "admin" ? "bg-[rgba(124,92,255,0.15)] text-[#7c5cff]" : "bg-[rgba(255,255,255,0.08)] text-[rgba(255,255,255,0.7)]"}`}>
                          {u.role === "admin" ? "Admin" : "User"}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <span className="text-sm text-[rgba(255,255,255,0.7)]">—</span>
                      </td>
                      <td className="py-4 px-4">
                        <span className="text-xs text-[rgba(255,255,255,0.45)]">
                          {u.createdAt
                            ? new Date(u.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })
                            : "—"}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <StatusBadge status={u.status} type="user" />
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => updateRoleMutation.mutate({
                              id: u.id,
                              role: u.role === "admin" ? "user" : "admin",
                            })}
                            className="h-7 px-2 text-xs text-[#7c5cff] hover:bg-[rgba(124,92,255,0.1)]"
                          >
                            {u.role === "admin" ? "Demote" : "Promote"}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => updateStatusMutation.mutate({
                              id: u.id,
                              status: u.status === "active" ? "inactive" : "active",
                            })}
                            className={`h-7 px-2 text-xs ${u.status === "active" ? "text-[#f87171] hover:bg-[rgba(248,113,113,0.1)]" : "text-[#4ade80] hover:bg-[rgba(74,222,128,0.1)]"}`}
                          >
                            {u.status === "active" ? (
                              <UserX className="w-3.5 h-3.5 mr-1" />
                            ) : (
                              <UserCheck className="w-3.5 h-3.5 mr-1" />
                            )}
                            {u.status === "active" ? "Deactivate" : "Activate"}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-[rgba(255,255,255,0.08)]">
              <p className="text-xs text-[rgba(255,255,255,0.45)]">
                Showing {usersData?.users.length ?? 0} of {usersData?.total ?? 0} users
              </p>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  disabled={userPage === 1}
                  onClick={() => setUserPage((p) => Math.max(1, p - 1))}
                  className="text-[rgba(255,255,255,0.7)] hover:text-white disabled:opacity-30"
                >
                  Previous
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  disabled={!usersData || usersData.users.length < 10}
                  onClick={() => setUserPage((p) => p + 1)}
                  className="text-[rgba(255,255,255,0.7)] hover:text-white disabled:opacity-30"
                >
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* ── Recent Documents ── */}
      <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6">
        <h3 className="text-lg font-medium text-white mb-6">Recent Documents</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[rgba(255,255,255,0.08)]">
                {["Document", "Category", "Status", "Uploaded"].map((h) => (
                  <th key={h} className="text-left py-3 px-4 text-xs font-medium uppercase tracking-wide text-[rgba(255,255,255,0.45)]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {documentsData?.documents.map((doc: { id: number; title: string; category: string; status: string; createdAt: Date | null }) => (
                <tr
                  key={doc.id}
                  className="border-b border-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.02)] transition-colors"
                >
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-[rgba(255,255,255,0.45)]" />
                      <span className="text-sm text-white">{doc.title}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-xs text-[rgba(255,255,255,0.45)] capitalize">{doc.category}</span>
                  </td>
                  <td className="py-4 px-4">
                    <StatusBadge status={doc.status} type="doc" />
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-xs text-[rgba(255,255,255,0.45)]">
                      {doc.createdAt
                        ? new Date(doc.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })
                        : "—"}
                    </span>
                  </td>
                </tr>
              ))}
              {(!documentsData || documentsData.documents.length === 0) && (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-sm text-[rgba(255,255,255,0.45)]">
                    No documents yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
