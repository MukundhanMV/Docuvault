import { useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import { useDropzone } from "react-dropzone";
import { Upload as UploadIcon, File, X, CheckCircle } from "lucide-react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { trpc } from "@/providers/trpc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";

interface FileUpload {
  file: File;
  id: string;
  progress: number;
  status: "uploading" | "done" | "error";
}

export default function UploadPage() {
  const navigate = useNavigate();
  const [uploadedFiles, setUploadedFiles] = useState<FileUpload[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const utils = trpc.useUtils();
  const uploadMutation = trpc.document.upload.useMutation({
    onSuccess: () => {
      utils.document.list.invalidate();
      utils.document.stats.invalidate();
      utils.activity.list.invalidate();
      toast.success("Document uploaded successfully!");
    },
    onError: (err) => {
      toast.error(err.message || "Failed to upload document");
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles: FileUpload[] = acceptedFiles.map((file) => ({
      file,
      id: Math.random().toString(36).substring(7),
      progress: 0,
      status: "uploading" as const,
    }));
    setUploadedFiles((prev) => [...prev, ...newFiles]);

    // Simulate upload progress
    newFiles.forEach((fileUpload) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 20;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          setUploadedFiles((prev) =>
            prev.map((f) =>
              f.id === fileUpload.id ? { ...f, progress: 100, status: "done" } : f
            )
          );
        } else {
          setUploadedFiles((prev) =>
            prev.map((f) =>
              f.id === fileUpload.id ? { ...f, progress: Math.round(progress) } : f
            )
          );
        }
      }, 200);
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "image/jpeg": [".jpg", ".jpeg"],
      "image/png": [".png"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
    },
    maxSize: 10 * 1024 * 1024, // 10MB
  });

  const removeFile = (id: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !category || uploadedFiles.length === 0) {
      toast.error("Please fill in all required fields and upload at least one file");
      return;
    }

    setIsSubmitting(true);

    try {
      for (const fileUpload of uploadedFiles) {
        // Simulate storing to Azure Blob Storage
        await uploadMutation.mutateAsync({
          title,
          description: description || undefined,
          category: category as "legal" | "finance" | "identity" | "medical" | "education" | "other",
          fileName: fileUpload.file.name,
          fileSize: fileUpload.file.size,
          fileType: fileUpload.file.type,
          blobUrl: `https://docuvault.blob.core.windows.net/documents/${Date.now()}-${fileUpload.file.name}`,
        });
      }

      // Reset form
      setTitle("");
      setDescription("");
      setCategory("");
      setUploadedFiles([]);
      navigate("/documents");
    } catch {
      // Error handled by mutation
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <DashboardLayout>
      {/* ── Breadcrumb ── */}
      <nav className="flex items-center gap-2 text-xs text-[rgba(255,255,255,0.45)] tracking-wide mb-6">
        <span>Dashboard</span>
        <span>/</span>
        <span className="text-white">Upload</span>
      </nav>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl"
      >
        <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
          Upload Document
        </h2>
        <p className="text-base text-[rgba(255,255,255,0.7)] mt-2">
          Upload and categorize your documents
        </p>

        {/* ── Dropzone ── */}
        <div
          {...getRootProps()}
          className={`
            mt-8 w-full h-[300px] rounded-2xl border-2 border-dashed 
            flex flex-col items-center justify-center cursor-pointer
            transition-all duration-200
            ${isDragActive
              ? "border-[#7c5cff] bg-[rgba(124,92,255,0.05)]"
              : "border-[rgba(255,255,255,0.08)] bg-[#262630] hover:border-[rgba(255,255,255,0.15)]"
            }
          `}
        >
          <input {...getInputProps()} />
          <UploadIcon className="w-16 h-16 text-[rgba(255,255,255,0.45)] mb-4" />
          <p className="text-xl text-[rgba(255,255,255,0.7)]">
            {isDragActive ? "Drop files here" : "Drag and drop your files here"}
          </p>
          <p className="text-base text-[#7c5cff] mt-2">or click to browse</p>
          <p className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide mt-4">
            Supports PDF, DOC, DOCX, JPG, PNG (max 10MB)
          </p>
        </div>

        {/* ── Uploaded Files List ── */}
        {uploadedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="mt-6 space-y-3"
          >
            {uploadedFiles.map((fileUpload) => (
              <div
                key={fileUpload.id}
                className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-xl p-4"
              >
                <div className="flex items-center gap-3">
                  <File className="w-5 h-5 text-[#7c5cff] flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{fileUpload.file.name}</p>
                    <p className="text-xs text-[rgba(255,255,255,0.45)]">
                      {formatFileSize(fileUpload.file.size)}
                    </p>
                  </div>
                  {fileUpload.status === "done" ? (
                    <CheckCircle className="w-5 h-5 text-[#4ade80] flex-shrink-0" />
                  ) : (
                    <span className="text-xs text-[rgba(255,255,255,0.45)] flex-shrink-0">
                      {fileUpload.progress}%
                    </span>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFile(fileUpload.id);
                    }}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-[rgba(255,255,255,0.45)] hover:text-[#f87171] hover:bg-[rgba(248,113,113,0.1)] transition-colors flex-shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {fileUpload.status === "uploading" && (
                  <Progress
                    value={fileUpload.progress}
                    className="mt-3 h-1 bg-[rgba(255,255,255,0.08)]"
                  />
                )}
              </div>
            ))}
          </motion.div>
        )}

        {/* ── Form ── */}
        <form onSubmit={handleSubmit} className="mt-8 space-y-6">
          <div>
            <label className="block text-sm font-medium text-white mb-2">Document Title *</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter document title"
              className="h-12 bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white placeholder:text-[rgba(255,255,255,0.45)] focus:border-[#7c5cff] focus:ring-[rgba(124,92,255,0.15)]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-white mb-2">Category *</label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="h-12 bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white focus:ring-[rgba(124,92,255,0.15)]">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="bg-[#262630] border-[rgba(255,255,255,0.08)]">
                <SelectItem value="legal" className="text-white focus:bg-[rgba(124,92,255,0.15)] focus:text-white">Legal</SelectItem>
                <SelectItem value="finance" className="text-white focus:bg-[rgba(124,92,255,0.15)] focus:text-white">Finance</SelectItem>
                <SelectItem value="identity" className="text-white focus:bg-[rgba(124,92,255,0.15)] focus:text-white">Identity</SelectItem>
                <SelectItem value="medical" className="text-white focus:bg-[rgba(124,92,255,0.15)] focus:text-white">Medical</SelectItem>
                <SelectItem value="education" className="text-white focus:bg-[rgba(124,92,255,0.15)] focus:text-white">Education</SelectItem>
                <SelectItem value="other" className="text-white focus:bg-[rgba(124,92,255,0.15)] focus:text-white">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-white mb-2">Description</label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a description (optional)"
              rows={4}
              className="bg-[rgba(255,255,255,0.05)] border-[rgba(255,255,255,0.08)] text-white placeholder:text-[rgba(255,255,255,0.45)] focus:border-[#7c5cff] focus:ring-[rgba(124,92,255,0.15)] resize-none"
            />
          </div>

          <Button
            type="submit"
            disabled={isSubmitting || uploadedFiles.length === 0 || !title || !category}
            className="w-full h-12 bg-[#7c5cff] hover:bg-[#6b4de8] text-white font-medium rounded-xl disabled:opacity-50"
          >
            {isSubmitting ? "Uploading..." : "Upload Document"}
          </Button>
        </form>
      </motion.div>
    </DashboardLayout>
  );
}
