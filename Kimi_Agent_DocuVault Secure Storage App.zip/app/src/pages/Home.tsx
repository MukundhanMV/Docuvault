import React, { useEffect, useRef, useState } from "react";
import type { LucideIcon } from "lucide-react";
import { Link } from "react-router";
import { motion, useInView } from "framer-motion";
import { Shield, FileCheck, Upload, ArrowRight } from "lucide-react";
import VaultWheel from "@/components/VaultWheel";

// ── Animated Section Wrapper ──
function AnimatedSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <motion.section
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.section>
  );
}

// ── Feature Card ──
function FeatureCard({ icon: Icon, title, description }: { icon: LucideIcon; title: string; description: string }) {
  return (
    <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-8 min-h-[280px] hover:-translate-y-1 hover:border-[rgba(124,92,255,0.3)] transition-all duration-300 group">
      <div className="w-16 h-16 rounded-xl bg-[rgba(124,92,255,0.1)] flex items-center justify-center mb-6">
        <Icon className="w-7 h-7 text-[#7c5cff]" />
      </div>
      <h3 className="text-[22px] font-medium text-white leading-7 tracking-tight">{title}</h3>
      <p className="text-sm text-[rgba(255,255,255,0.7)] mt-3 leading-[22px] tracking-tight">{description}</p>
    </div>
  );
}

// ── Step Item ──
function StepItem({ number, title, description, isLast }: { number: string; title: string; description: string; isLast?: boolean }) {
  return (
    <div className="relative flex-1 text-center px-4">
      <span className="text-[72px] font-semibold text-[rgba(124,92,255,0.12)] leading-none select-none">{number}</span>
      <h3 className="text-[22px] font-medium text-white mt-4 tracking-tight">{title}</h3>
      <p className="text-sm text-[rgba(255,255,255,0.7)] mt-3 leading-[22px] max-w-[280px] mx-auto">{description}</p>
      {!isLast && (
        <>
          <div className="hidden lg:block absolute top-10 right-0 w-1/2 h-px bg-[rgba(255,255,255,0.08)] translate-x-1/2" />
          <div className="lg:hidden w-px h-12 bg-[rgba(255,255,255,0.08)] mx-auto mt-6" />
        </>
      )}
    </div>
  );
}

// ── Testimonial Card ──
function TestimonialCard({ quote, name, role }: { quote: string; name: string; role: string }) {
  return (
    <div className="bg-[#262630] border border-[rgba(255,255,255,0.08)] rounded-2xl p-8">
      <p className="text-base text-[rgba(255,255,255,0.7)] italic leading-7">&ldquo;{quote}&rdquo;</p>
      <div className="flex items-center gap-3 mt-6">
        <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#7c5cff] to-[#5a3fd1] flex items-center justify-center text-sm font-medium text-white flex-shrink-0">
          {name.charAt(0)}
        </div>
        <div>
          <p className="text-sm font-medium text-white">{name}</p>
          <p className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide">{role}</p>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative min-h-screen bg-[#0e0e14]">
      {/* ── 3D Vault Background ── */}
      <VaultWheel />

      {/* ── Navigation ── */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between px-6 lg:px-10 transition-all duration-300 ${
          scrolled ? "bg-[#0e0e14]/80 backdrop-blur-xl border-b border-[rgba(255,255,255,0.08)]" : ""
        }`}
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-[#7c5cff] flex items-center justify-center">
            <Shield className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-base font-semibold text-white tracking-tight">DocuVault</span>
        </div>
        <div className="flex items-center gap-3">
          <Link
            to="/login"
            className="text-sm text-[rgba(255,255,255,0.7)] hover:text-white transition-colors px-4 py-2"
          >
            Sign In
          </Link>
          <Link
            to="/login"
            className="text-sm font-medium text-white bg-[#7c5cff] hover:bg-[#6b4de8] px-5 py-2.5 rounded-xl transition-colors"
          >
            Get Started
          </Link>
        </div>
      </nav>

      {/* ── Hero Section ── */}
      <section className="relative z-10 min-h-screen flex items-center justify-center px-6">
        <div className="text-center pointer-events-none" style={{ maxWidth: "640px" }}>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="text-xs font-medium uppercase tracking-[0.1em] text-[rgba(255,255,255,0.45)] mb-6"
          >
            Secure Document Management
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 0.6 }}
            className="text-5xl sm:text-6xl lg:text-[80px] font-semibold leading-[1.1] tracking-[-2.4px] gradient-text"
          >
            Your Documents.
            <br />
            Locked Safe.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-lg sm:text-xl text-[rgba(255,255,255,0.7)] mt-8 leading-8 max-w-[520px] mx-auto"
          >
            Upload, verify, and manage your important documents with bank-grade security.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65, duration: 0.6 }}
            className="mt-10 pointer-events-auto"
          >
            <Link
              to="/login"
              className="inline-flex items-center gap-2 text-base font-medium text-white bg-[#7c5cff] hover:bg-[#6b4de8] hover:scale-[1.03] px-10 py-4 rounded-full transition-all duration-200 glow-subtle hover:glow-purple"
            >
              Get Started
              <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ── Features Section ── */}
      <div className="relative z-10 bg-[#0e0e14]">
        <AnimatedSection className="py-24 lg:py-32 px-6 lg:px-10 max-w-[1280px] mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
              Everything You Need
            </h2>
            <p className="text-base text-[rgba(255,255,255,0.7)] mt-4">
              Powerful tools to manage your document workflow
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FeatureCard
              icon={Shield}
              title="Secure Storage"
              description="Documents encrypted at rest with AES-256. Role-based access ensures only authorized eyes see your files."
            />
            <FeatureCard
              icon={FileCheck}
              title="Verification System"
              description="Submit documents for review. Track approval status from pending to verified with a complete audit trail."
            />
            <FeatureCard
              icon={Upload}
              title="Easy Upload"
              description="Drag and drop any file type. Automatic categorization, version control, and intelligent search."
            />
          </div>
        </AnimatedSection>

        {/* ── How It Works ── */}
        <AnimatedSection className="py-24 lg:py-32 px-6 lg:px-10 bg-[#111118]">
          <div className="max-w-[1280px] mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
                How It Works
              </h2>
              <p className="text-base text-[rgba(255,255,255,0.7)] mt-4">
                Get started in three simple steps
              </p>
            </div>

            <div className="flex flex-col lg:flex-row gap-8 lg:gap-0">
              <StepItem
                number="01"
                title="Create Account"
                description="Sign up with your email. Verify your identity and set up your secure vault in under two minutes."
              />
              <StepItem
                number="02"
                title="Upload Documents"
                description="Drag and drop files or browse to select. Add titles, descriptions, and categories for easy organization."
              />
              <StepItem
                number="03"
                title="Verify & Share"
                description="Submit documents for admin verification. Once approved, your documents are certified and ready to share."
                isLast
              />
            </div>
          </div>
        </AnimatedSection>

        {/* ── Testimonials ── */}
        <AnimatedSection className="py-24 lg:py-32 px-6 lg:px-10 max-w-[1280px] mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
              Trusted by Professionals
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TestimonialCard
              quote="DocuVault transformed how our legal team handles sensitive documents. The verification system alone saved us weeks of manual review."
              name="Sarah Chen"
              role="Legal Director"
            />
            <TestimonialCard
              quote="The security features give us confidence. Bank-grade encryption with an interface that actually makes sense."
              name="Marcus Johnson"
              role="CTO"
            />
            <TestimonialCard
              quote="We migrated all our compliance documentation to DocuVault. The audit trail and approval workflow are exactly what we needed."
              name="Priya Sharma"
              role="Compliance Officer"
            />
          </div>
        </AnimatedSection>

        {/* ── CTA Section ── */}
        <AnimatedSection className="py-24 lg:py-32 px-6 lg:px-10 bg-gradient-to-b from-[#0e0e14] to-[#151520]">
          <div className="text-center max-w-[600px] mx-auto">
            <h2 className="text-[42px] font-medium text-white leading-[48px] tracking-[-0.84px]">
              Ready to Secure Your Documents?
            </h2>
            <p className="text-xl text-[rgba(255,255,255,0.7)] mt-6">
              Join thousands of professionals who trust DocuVault
            </p>
            <div className="mt-10">
              <Link
                to="/login"
                className="inline-flex items-center gap-2 text-base font-medium text-white bg-[#7c5cff] hover:bg-[#6b4de8] hover:scale-[1.03] px-10 py-4 rounded-full transition-all duration-200 glow-purple"
              >
                Get Started Free
                <ArrowRight className="w-4 h-4" />
              </Link>
              <p className="text-xs text-[rgba(255,255,255,0.45)] tracking-wide mt-4">
                No credit card required
              </p>
            </div>
          </div>
        </AnimatedSection>

        {/* ── Footer ── */}
        <footer className="py-10 px-6 lg:px-10 border-t border-[rgba(255,255,255,0.08)]">
          <div className="max-w-[1280px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-[#7c5cff] flex items-center justify-center">
                <Shield className="w-3 h-3 text-white" />
              </div>
              <span className="text-sm font-medium text-white">DocuVault</span>
            </div>
            <p className="text-xs text-[rgba(255,255,255,0.45)]">
              &copy; 2026 DocuVault. Secure document storage and verification.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
