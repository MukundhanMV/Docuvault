import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { activities } from "@db/schema";

export const activityRouter = createRouter({
  // ──────────────────────────────────────────
  // List recent activities for the current user
  // ──────────────────────────────────────────
  list: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;
      const isAdmin = ctx.user.role === "admin";
      const limit = input?.limit ?? 10;

      // Admin sees all activities, users see only theirs
      const condition = isAdmin ? undefined : eq(activities.userId, userId);

      const activityList = await db
        .select()
        .from(activities)
        .where(condition)
        .orderBy(desc(activities.createdAt))
        .limit(limit);

      return activityList;
    }),
});
