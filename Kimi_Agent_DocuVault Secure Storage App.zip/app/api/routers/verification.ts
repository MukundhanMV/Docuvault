import { z } from "zod";
import { eq, desc, sql, and, gte } from "drizzle-orm";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { documents, verificationLogs } from "@db/schema";

export const verificationRouter = createRouter({
  // ──────────────────────────────────────────
  // Admin: List pending documents for review
  // ──────────────────────────────────────────
  pending: adminQuery
    .input(
      z.object({
        page: z.number().min(1).default(1),
        limit: z.number().min(1).max(50).default(20),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const page = input?.page ?? 1;
      const limit = input?.limit ?? 20;
      const offset = (page - 1) * limit;

      const [countResult] = await db
        .select({ count: sql<number>`count(*)` })
        .from(documents)
        .where(eq(documents.status, "pending"));
      const total = countResult?.count ?? 0;

      const pendingDocs = await db
        .select()
        .from(documents)
        .where(eq(documents.status, "pending"))
        .orderBy(desc(documents.createdAt))
        .limit(limit)
        .offset(offset);

      return { documents: pendingDocs, total };
    }),

  // ──────────────────────────────────────────
  // Admin: Get verification stats
  // ──────────────────────────────────────────
  stats: adminQuery.query(async () => {
    const db = getDb();

    // Pending count
    const [pendingResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(eq(documents.status, "pending"));

    // Approved today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [approvedTodayResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(
        and(
          eq(documents.status, "verified"),
          gte(documents.verifiedAt, today)
        )
      );

    // Rejected this week
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const [rejectedWeekResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(
        and(
          eq(documents.status, "rejected"),
          gte(documents.verifiedAt, weekAgo)
        )
      );

    return {
      pending: pendingResult?.count ?? 0,
      approvedToday: approvedTodayResult?.count ?? 0,
      rejectedThisWeek: rejectedWeekResult?.count ?? 0,
    };
  }),

  // ──────────────────────────────────────────
  // Admin: Get verification logs
  // ──────────────────────────────────────────
  logs: adminQuery
    .input(
      z.object({
        documentId: z.number().positive().optional(),
        limit: z.number().min(1).max(50).default(20),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit ?? 20;

      const conditions = [];
      if (input?.documentId) {
        conditions.push(eq(verificationLogs.documentId, input.documentId));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const logs = await db
        .select()
        .from(verificationLogs)
        .where(whereClause)
        .orderBy(desc(verificationLogs.createdAt))
        .limit(limit);

      return logs;
    }),
});
