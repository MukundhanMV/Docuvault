import { z } from "zod";
import { eq, like, sql, desc } from "drizzle-orm";
import { createRouter, authedQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { users, documents } from "@db/schema";

export const userRouter = createRouter({
  // ──────────────────────────────────────────
  // Get current user profile
  // ──────────────────────────────────────────
  profile: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, ctx.user.id));
    return user;
  }),

  // ──────────────────────────────────────────
  // Update user profile
  // ──────────────────────────────────────────
  updateProfile: authedQuery
    .input(z.object({ name: z.string().min(1).max(255).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(users)
        .set({ name: input.name })
        .where(eq(users.id, ctx.user.id));

      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id));
      return user;
    }),

  // ──────────────────────────────────────────
  // Admin: List all users
  // ──────────────────────────────────────────
  list: adminQuery
    .input(
      z.object({
        page: z.number().min(1).default(1),
        limit: z.number().min(1).max(100).default(20),
        search: z.string().optional(),
        status: z.enum(["active", "inactive"]).optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const page = input?.page ?? 1;
      const limit = input?.limit ?? 20;
      const offset = (page - 1) * limit;

      const conditions = [];

      if (input?.search) {
        conditions.push(like(users.name, `%${input.search}%`));
      }

      if (input?.status) {
        conditions.push(eq(users.status, input.status));
      }

      const whereClause = conditions.length > 0 ? sql.join(conditions, sql` AND `) : undefined;

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(users)
        .where(whereClause);
      const total = countResult[0]?.count ?? 0;

      const userList = await db
        .select()
        .from(users)
        .where(whereClause)
        .orderBy(desc(users.createdAt))
        .limit(limit)
        .offset(offset);

      return { users: userList, total };
    }),

  // ──────────────────────────────────────────
  // Admin: Update user role
  // ──────────────────────────────────────────
  updateRole: adminQuery
    .input(
      z.object({
        id: z.number().positive(),
        role: z.enum(["user", "admin"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(users)
        .set({ role: input.role })
        .where(eq(users.id, input.id));

      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, input.id));
      return user;
    }),

  // ──────────────────────────────────────────
  // Admin: Update user status
  // ──────────────────────────────────────────
  updateStatus: adminQuery
    .input(
      z.object({
        id: z.number().positive(),
        status: z.enum(["active", "inactive"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(users)
        .set({ status: input.status })
        .where(eq(users.id, input.id));

      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, input.id));
      return user;
    }),

  // ──────────────────────────────────────────
  // Admin: Get user stats
  // ──────────────────────────────────────────
  stats: adminQuery.query(async () => {
    const db = getDb();

    const [totalResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);

    const [activeResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(eq(users.status, "active"));

    const [docResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents);

    return {
      totalUsers: totalResult?.count ?? 0,
      activeUsers: activeResult?.count ?? 0,
      totalDocuments: docResult?.count ?? 0,
    };
  }),
});
