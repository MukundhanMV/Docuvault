import { z } from "zod";
import { eq, and, like, desc, asc, sql } from "drizzle-orm";
import { createRouter, authedQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { documents, activities } from "@db/schema";

export const documentRouter = createRouter({
  // ──────────────────────────────────────────
  // Upload a new document
  // ──────────────────────────────────────────
  upload: authedQuery
    .input(
      z.object({
        title: z.string().min(1).max(255),
        description: z.string().max(1000).optional(),
        category: z.enum(["legal", "finance", "identity", "medical", "education", "other"]),
        fileName: z.string().min(1),
        fileSize: z.number().positive(),
        fileType: z.string().min(1),
        blobUrl: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      const [doc] = await db.insert(documents).values({
        title: input.title,
        description: input.description || null,
        category: input.category,
        fileName: input.fileName,
        fileSize: input.fileSize,
        fileType: input.fileType,
        blobUrl: input.blobUrl,
        uploadedBy: userId,
      });

      // Create activity log
      await db.insert(activities).values({
        userId,
        action: "upload",
        targetId: Number(doc.insertId),
        targetType: "document",
        details: `Uploaded "${input.title}"`,
      });

      return { id: Number(doc.insertId), ...input, uploadedBy: userId, status: "pending" as const };
    }),

  // ──────────────────────────────────────────
  // List documents (with filters, admin sees all)
  // ──────────────────────────────────────────
  list: authedQuery
    .input(
      z.object({
        page: z.number().min(1).default(1),
        limit: z.number().min(1).max(100).default(20),
        search: z.string().optional(),
        category: z.enum(["legal", "finance", "identity", "medical", "education", "other"]).optional(),
        status: z.enum(["pending", "verified", "rejected"]).optional(),
        sort: z.string().default("created_at_desc"),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;
      const isAdmin = ctx.user.role === "admin";
      const page = input?.page ?? 1;
      const limit = input?.limit ?? 20;
      const offset = (page - 1) * limit;

      const conditions = [];

      // Non-admin users only see their own documents
      if (!isAdmin) {
        conditions.push(eq(documents.uploadedBy, userId));
      }

      if (input?.search) {
        conditions.push(like(documents.title, `%${input.search}%`));
      }

      if (input?.category) {
        conditions.push(eq(documents.category, input.category));
      }

      if (input?.status) {
        conditions.push(eq(documents.status, input.status));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      // Get total count
      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(documents)
        .where(whereClause);
      const total = countResult[0]?.count ?? 0;

      // Get documents with sorting
      const sortField = input?.sort?.startsWith("created_at_asc") ? asc(documents.createdAt) : desc(documents.createdAt);

      const docs = await db
        .select()
        .from(documents)
        .where(whereClause)
        .orderBy(sortField)
        .limit(limit)
        .offset(offset);

      return { documents: docs, total };
    }),

  // ──────────────────────────────────────────
  // Get a single document by ID
  // ──────────────────────────────────────────
  getById: authedQuery
    .input(z.object({ id: z.number().positive() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const isAdmin = ctx.user.role === "admin";

      const [doc] = await db
        .select()
        .from(documents)
        .where(eq(documents.id, input.id));

      if (!doc) {
        throw new Error("Document not found");
      }

      // Non-admin can only view their own documents
      if (!isAdmin && doc.uploadedBy !== ctx.user.id) {
        throw new Error("Access denied");
      }

      return doc;
    }),

  // ──────────────────────────────────────────
  // Delete a document
  // ──────────────────────────────────────────
  delete: authedQuery
    .input(z.object({ id: z.number().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const isAdmin = ctx.user.role === "admin";

      // Verify ownership
      const [doc] = await db
        .select()
        .from(documents)
        .where(eq(documents.id, input.id));

      if (!doc) {
        throw new Error("Document not found");
      }

      if (!isAdmin && doc.uploadedBy !== ctx.user.id) {
        throw new Error("Access denied");
      }

      await db.delete(documents).where(eq(documents.id, input.id));

      // Create activity log
      await db.insert(activities).values({
        userId: ctx.user.id,
        action: "delete",
        targetId: input.id,
        targetType: "document",
        details: `Deleted "${doc.title}"`,
      });

      return { success: true };
    }),

  // ──────────────────────────────────────────
  // Get document stats for dashboard
  // ──────────────────────────────────────────
  stats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;
    const isAdmin = ctx.user.role === "admin";

    const conditions = isAdmin ? undefined : eq(documents.uploadedBy, userId);

    const [totalResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(conditions);

    const [verifiedResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(conditions ? and(conditions, eq(documents.status, "verified")) : eq(documents.status, "verified"));

    const [pendingResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(conditions ? and(conditions, eq(documents.status, "pending")) : eq(documents.status, "pending"));

    const [rejectedResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(conditions ? and(conditions, eq(documents.status, "rejected")) : eq(documents.status, "rejected"));

    return {
      total: totalResult?.count ?? 0,
      verified: verifiedResult?.count ?? 0,
      pending: pendingResult?.count ?? 0,
      rejected: rejectedResult?.count ?? 0,
    };
  }),

  // ──────────────────────────────────────────
  // Admin: List all documents
  // ──────────────────────────────────────────
  adminList: adminQuery
    .input(
      z.object({
        page: z.number().min(1).default(1),
        limit: z.number().min(1).max(50).default(20),
        status: z.enum(["pending", "verified", "rejected"]).optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const page = input?.page ?? 1;
      const limit = input?.limit ?? 20;
      const offset = (page - 1) * limit;

      const conditions = [];
      if (input?.status) {
        conditions.push(eq(documents.status, input.status));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const [countResult] = await db
        .select({ count: sql<number>`count(*)` })
        .from(documents)
        .where(whereClause);
      const total = countResult?.count ?? 0;

      const docs = await db
        .select()
        .from(documents)
        .where(whereClause)
        .orderBy(desc(documents.createdAt))
        .limit(limit)
        .offset(offset);

      return { documents: docs, total };
    }),

  // ──────────────────────────────────────────
  // Admin: verify or reject a document
  // ──────────────────────────────────────────
  verify: adminQuery
    .input(
      z.object({
        id: z.number().positive(),
        status: z.enum(["verified", "rejected"]),
        reason: z.string().max(500).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const adminId = ctx.user.id;

      const [doc] = await db
        .select()
        .from(documents)
        .where(eq(documents.id, input.id));

      if (!doc) {
        throw new Error("Document not found");
      }

      const previousStatus = doc.status;

      await db
        .update(documents)
        .set({
          status: input.status,
          verifiedBy: adminId,
          verifiedAt: new Date(),
          rejectionReason: input.reason || null,
        })
        .where(eq(documents.id, input.id));

      // Create verification log
      const { verificationLogs } = await import("@db/schema");
      await db.insert(verificationLogs).values({
        documentId: input.id,
        verifiedBy: adminId,
        previousStatus,
        newStatus: input.status,
        reason: input.reason || null,
      });

      // Create activity log
      await db.insert(activities).values({
        userId: adminId,
        action: input.status === "verified" ? "verify" : "reject",
        targetId: input.id,
        targetType: "document",
        details: `${input.status === "verified" ? "Approved" : "Rejected"} "${doc.title}"`,
      });

      return { ...doc, status: input.status, verifiedBy: adminId, verifiedAt: new Date() };
    }),
});
