import { authRouter } from "./auth-router";
import { documentRouter } from "./routers/document";
import { userRouter } from "./routers/user";
import { activityRouter } from "./routers/activity";
import { verificationRouter } from "./routers/verification";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  document: documentRouter,
  user: userRouter,
  activity: activityRouter,
  verification: verificationRouter,
});

export type AppRouter = typeof appRouter;
